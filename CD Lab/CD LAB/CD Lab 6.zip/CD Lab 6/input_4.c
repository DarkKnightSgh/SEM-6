if (c > d) {
    do {
        a = a + 1;
    } while (a > b);
    b = a;
}
