// int main()
// {
// 	int a;
// 	int b;
// 	a =10;
// 	b = 20;
// 	float d = 10;
// 	float c = "a";
// 	char c = "a";
// 		{
// 		int j = 10;
// 		}
	
// }

if(b>10)
{

}