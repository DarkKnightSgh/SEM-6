if (a > b)
{
    a = a + 1;
    b = b - 1;
}
else
{
    a = a - 1;
    b = b - 1;
    if (b < 0)
    {
        b = b + 1;
    }
    else
    {
        b = 0;
    }
}
