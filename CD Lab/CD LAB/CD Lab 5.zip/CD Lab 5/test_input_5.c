do
{
    a = a + 1;
    if (c > d)
    {
        c = c + 1;
    }
}
while (a > b)