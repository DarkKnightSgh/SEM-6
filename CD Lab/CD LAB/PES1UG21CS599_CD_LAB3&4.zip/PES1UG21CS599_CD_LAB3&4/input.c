int main()
{
	int a;
	int b;
	a =10;
	b = 20;
	float d = 10.01;
	char c = 'a';	
}

